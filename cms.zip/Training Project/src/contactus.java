
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class contactus {
    
        Frame f1;
	Panel p1;
	Label l1,l2,l3,l4,l5,l6,l7,l8;
        JLabel  l9;
        ImageIcon im;
        contactus()
	{
		f1=new Frame("contact us");
		p1=new Panel();
                
                l1=new Label("College Address:");
                l2=new Label("Ramnagaria,Jagatpura");
                l3=new Label("Jaipur 302017");
                l4=new Label("Rajasthan");
                l5=new Label("India");
                l6=new Label("Tel. : +91-0141- 5160400, 2759609, 2752165 & 2752167");
                l7=new Label("Fax: +91-0141-2759555");
                l8=new Label("E-mail: info@skit.ac.in");
                
                im=new ImageIcon("d:\\Training Project\\skitlogo.png");
                l9=new JLabel(im);
          
                
                
                
                
                f1.add(p1);
                p1.add(l1);
                p1.add(l2);
                p1.add(l3);
                p1.add(l4);
                p1.add(l5);
                p1.add(l6);
                p1.add(l7);
                p1.add(l8);
                p1.add(l9);
                
                l1.setBounds(350,250,600,40);
		l2.setBounds(350,300,600,40);
                l3.setBounds(350,350,600,40);
                l4.setBounds(350,400,600,40);
                l5.setBounds(350,450,600,40);
                l6.setBounds(350,500,600,40);
                l7.setBounds(350,550,600,40);
                l8.setBounds(350,600,600,40);
                
                l9.setBounds(450,10,200,200);
        
                p1.setLayout(null);
		
		f1.setSize(1000,700);
		f1.setVisible(true);
		/*f1.setLocationRelativeTo(null);*/
                f1.setLocationRelativeTo(null);
		p1.setLayout(null);
		f1.setResizable(false);

                Font fon=new Font("",Font.PLAIN,19);
		
		l1.setFont(fon);
		l2.setFont(fon);
                l3.setFont(fon);
                l4.setFont(fon);
                l5.setFont(fon);
                l6.setFont(fon);
                l7.setFont(fon);
                l8.setFont(fon);
        }
        
        public static void main(String args[])
	{
                new contactus();
	}
    
}
