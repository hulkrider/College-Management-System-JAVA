import java.awt.*;
import javax.swing.*;

class About  
{
   JFrame f1;
   JPanel p1;
   JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l11,l12,l13,l14,l15,l16,l17,l18,l19,l20;
   ImageIcon im;
   
   About()
   {
       f1 = new JFrame("About");
       p1 = new JPanel();
       
       l1=new JLabel("Type :");
       l2=new JLabel("Established :");
       l4=new JLabel("Affliation :");
       l5=new JLabel("Director :");
       l6=new JLabel("Undergraduates :");
       l7=new JLabel("Postgraduates :");
       l3=new JLabel("Accredition :");
       l8=new JLabel("Campus :");
       l9=new JLabel("Website :");
       l11=new JLabel("Self Financed College");
       l12=new JLabel("2000");
       l14=new JLabel("Rajasthan Technical University(RTU),"+"Kota");
       l15=new JLabel("Dr.Jaipal Meel");
       l16=new JLabel("B.Tech");
       l17=new JLabel("MBA,M.Tech");
       l13=new JLabel("NBA");
       l18=new JLabel("Urban");
       l19=new JLabel("https: //www.skit.ac.in");
       
       im=new ImageIcon("d:\\Training Project\\skitlogo.png");
       l20=new JLabel(im);
       
       f1.add(p1);
       
       p1.add(l1);
       p1.add(l2);
       p1.add(l3);
       p1.add(l4);
       p1.add(l5);
       p1.add(l6);
       p1.add(l7);
       p1.add(l8);
       p1.add(l9);
       p1.add(l11);
       p1.add(l12);
       p1.add(l13);
       p1.add(l14);
       p1.add(l15);
       p1.add(l16);
       p1.add(l17);
       p1.add(l18);
       p1.add(l19);
       p1.add(l20);
       
       l1.setBounds(50,260,150,25);
       l2.setBounds(50,310,150,25);
       l3.setBounds(50,360,150,25);
       l4.setBounds(50,410,150,25);
       l5.setBounds(50,460,150,25);
       l6.setBounds(50,510,150,25);
       l7.setBounds(50,560,150,25);
       l8.setBounds(50,610,150,25);
       l9.setBounds(50,660,150,25);
       l11.setBounds(200,260,150,25);
       l12.setBounds(200,310,400,25);
       l13.setBounds(200,360,150,25);
       l14.setBounds(200,410,400,25);
       l15.setBounds(200,460,150,25);
       l16.setBounds(200,510,150,25);
       l17.setBounds(200,560,350,25);
       l18.setBounds(200,610,150,25);
       l19.setBounds(200,660,150,25);
       l20.setBounds(150,20,225,225);
       
       p1.setLayout(null);
       f1.setVisible(true);
       f1.setSize(550,740);
       f1.setLocationRelativeTo(null);
       f1.setResizable(false);
       
   }
   public static void main(String args[])
   {
       About obj=new About();
   }
   void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
