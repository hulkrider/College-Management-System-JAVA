import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.sql.*;

class paymentinput extends DBCON implements ActionListener
{
	JFrame f1;
	JPanel p1;
	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11;
	JTextField tf1,tf2,tf3,tf4,tf5,tf6,tf7,tf8,tf9,tf10,tf11;
	JComboBox cb4;
	JButton b1,b2,b3,b4;
	paymentinput()
	{
		f1=new JFrame("Fees breakdown");
		p1=new JPanel();
		l1=new JLabel("Select Student ID");	
		l2=new JLabel("Student Name");
		l3=new JLabel("Father Name");
		l4=new JLabel("Course");
                l5=new JLabel("Branch");
                l6=new JLabel("Year");
                l7=new JLabel("Tuition fees");
                l8=new JLabel("Development fees");
                l9=new JLabel("Accredition fees");
                l10=new JLabel("Registration fees");
                l11=new JLabel("Extra fees");
		
                tf1=new JTextField();
		tf2=new JTextField();
		tf3=new JTextField();
                tf4=new JTextField();
                tf5=new JTextField();
                tf6=new JTextField();
                tf7=new JTextField();
                tf8=new JTextField();
                tf9=new JTextField();
                tf10=new JTextField();
                tf11=new JTextField();


		b1=new JButton("Pay Now");
		b2=new JButton("Back");
                b3=new JButton("Load");
                b4=new JButton("Upload");


		f1.add(p1);
		f1.setSize(575,650);
		f1.setVisible(true);
		f1.setLocationRelativeTo(null);
		p1.setLayout(null);
		f1.setResizable(false);

		p1.add(l1);
                p1.add(l2);
                p1.add(l3);
                p1.add(l4);
                p1.add(l5);
                p1.add(l6);
                p1.add(l7);
                p1.add(l8);
                p1.add(l9);
                p1.add(l10);
                p1.add(l11);
                p1.add(tf1);
                p1.add(tf2);
                p1.add(tf3);
                p1.add(tf4);
                p1.add(tf5);
                p1.add(tf6);
                p1.add(tf7);
                p1.add(tf8);
                p1.add(tf9);
                p1.add(tf10);
                p1.add(tf11);
		p1.add(b1);p1.add(b2);p1.add(b3);p1.add(b4);

		l1.setBounds(50,40,150,25);
		l2.setBounds(50,80,150,25);
		l3.setBounds(50,120,150,25);
		l4.setBounds(50,160,150,25);
                l5.setBounds(50,200,150,25);
                l6.setBounds(50,240,150,25);
                l7.setBounds(50,280,150,25);
                l8.setBounds(50,320,150,25);
                l9.setBounds(50,360,150,25);
                l10.setBounds(50,400,150,25);
                l11.setBounds(50,440,150,25);
                
		tf1.setBounds(225,40,150,25);
		tf2.setBounds(225,80,150,25);
		tf3.setBounds(225,120,150,25);
                tf4.setBounds(225,160,150,25);
                tf5.setBounds(225,200,150,25);
                tf6.setBounds(225,240,150,25);
                tf7.setBounds(225,280,150,25);
                tf8.setBounds(225,320,150,25);
                tf9.setBounds(225,360,150,25);
                tf10.setBounds(225,400,150,25);
                tf11.setBounds(225,440,150,25);
                
                
		
		b1.setBounds(190,500,100,25);
		b2.setBounds(340,500,95,25);	
                b3.setBounds(400,40,150,25);
		b4.setBounds(50,500,100,25);
                /*b1.addActionListener(this);	
		b2.addActionListener(this);
                b3.addActionListener(this);
                b4.addActionListener(this); */
	}
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==b1)
                {   
                    JOptionPane.showMessageDialog(f1,"b1 working");
		}
		if(ae.getSource()==b2)
		{
			JOptionPane.showMessageDialog(f1,"b2 working");
                  
		}
                if(ae.getSource()==b3)
		{
			JOptionPane.showMessageDialog(f1,"b3 working");
                  
                    try
                    {   
                        int id=Integer.parseInt(tf1.getText());
                        
                    String viewquery="select sname,fname,course,branch from studentreg where sid="+id;
                            
                                              
                        Statement stmt=con.createStatement();
                        ResultSet rs=stmt.executeQuery(viewquery);
	
                    while(rs.next())
                        {    
                           
                          tf2.setText(rs.getString(1));
                          tf3.setText(rs.getString(2));
                          tf4.setText(rs.getString(3));
                          tf5.setText(rs.getString(4));
                          tf7.setText("40000");
                          tf8.setText("10000");
                          tf9.setText("4000");
                          tf10.setText("2000");
                          
                          
                       }
                    
                    
                    }
                    
                    catch(Exception e)
                    {
                      System.out.println("data not found"+e);
                    }   
                   
                }
                if(ae.getSource()==b4)
                {   
                    JOptionPane.showMessageDialog(f1,"b4 working");
                    
                    int id=Integer.parseInt(tf1.getText());
                    
                     try
                     {
                    String viewquery="select sname,fname,course,branch from studentreg where sid="+id;
                            
                                              
                        Statement stmt=con.createStatement();
                        ResultSet rs=stmt.executeQuery(viewquery);
	
                    while(rs.next())
                        {    
                           
                          tf2.setText(rs.getString(1));
                          tf3.setText(rs.getString(2));
                          tf4.setText(rs.getString(3));
                          tf5.setText(rs.getString(4));
                          tf7.setText("40000");
                          tf8.setText("10000");
                          tf9.setText("4000");
                          tf10.setText("2000");
                          
                        
                    
                        int year=Integer.parseInt(tf6.getText());
                        int late=Integer.parseInt(tf11.getText());
                        
                         
                        
                    String insertquery="insert into studentfees values(?,?,?,?,?,?,?,?,?,?,?)";
                    
                    PreparedStatement pst=con.prepareStatement(insertquery);
                    
                    pst.setInt(1,id);
                    pst.setString(2,tf2);
                    pst.setString(3,tf3);
                    pst.setString(4,tf4);
                    pst.setString(5,tf5);
                    pst.setInt(6,year);
                    pst.setInt(7,tf7);
                    pst.setInt(8,tf8);
                    pst.setInt(9,tf9);
                    pst.setString(10,tf10);
                    pst.setInt(11,late);
                    
                    pst.executeUpdate();
                    
                    } 
                                           
                    
                    
                        /*String str1=t1.getText();
                        String str2=t2.getText();
                        String str3=t3.getText();
                        
                        String sc41=c41.getSelectedItem().toString();
                        String sc42=c42.getSelectedItem().toString();
                        String sc43=c43.getSelectedItem().toString();
                        
                        String dt=sc41+""+sc42+""+sc43;
                        
                        String sc5=c5.getSelectedItem().toString();
                        
                        String str6=t6.getText();
                        String str7=t7.getText();
                        String str8=t8.getText();
                        String str9=t9.getText();
                        String sc10=c10.getSelectedItem().toString();
                        String sc11=c11.getSelectedItem().toString();
                    
                 try
                {
                    String insertquery="insert into studentreg values(?,?,?,?,?,?,?,?,?,?,?)";
                    
                    PreparedStatement pst=con.prepareStatement(insertquery);
                    
                    pst.setInt(1,Integer.parseInt(str1));
                    pst.setString(2,str2);
                    pst.setString(3,str3);
                    pst.setString(4,dt);
                    pst.setString(5,sc5);
                    pst.setString(6,str6);
                    pst.setString(7,str7);
                    pst.setString(8,str8);
                    pst.setString(9,str9);
                    pst.setString(10,sc10);
                    pst.setString(11,sc11);
                    
                    pst.executeUpdate();
                                
                     */           
                 /*   System.out.println("Data inserted");
               
                    JOptionPane.showMessageDialog(f1,"Data inserted");
                }
                catch(Exception e)
                {    
                 System.out.println("Data not inserted"+e);
                  JOptionPane.showMessageDialog(f1,"Data not inserted");  
                }
                    
		}*/
		
	}
                 catch(Exception e) 
                 {
                     System.out.println("Data not inserted"+e);
                 }    
                }
        }        
	public static void main(String a[])
	{
		new paymentinput();
	}
}
