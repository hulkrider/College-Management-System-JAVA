import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.sql.*;

class teacherreg extends DBCON implements ActionListener
{
	JFrame f1;
	JPanel p1;
	JLabel l1,l2,l3,l4,l5,l6,l7,l8, l9, l10;
	TextField t1,t2,t3,t4,t6,t7,t10;
	JComboBox c91, c92, c93, c5, c8;
	JButton b3,b1,b2;
 
	teacherreg()
	{
		f1=new JFrame("Teacher Registration");
		p1=new JPanel();

		l1=new JLabel("Teacher Id");
		l2=new JLabel("Teacher Name");
		l3=new JLabel("Age");
		l4=new JLabel("Contact no.");
		l5=new JLabel("Gender");
		l6=new JLabel("Address");
		l7=new JLabel("Qualification");
		l8=new JLabel("Marital Status");
		l9=new JLabel("Date Of Joining ");
		l10=new JLabel("Salary");

		b3=new JButton("Back");
		b1=new JButton("Save");
		b2=new JButton("Reset");

		String str[] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};

		c91=new JComboBox();
		c92=new JComboBox(str);
		c93=new JComboBox();
		c5=new JComboBox();
                c8=new JComboBox();
                

		c8.addItem("Single");
		c8.addItem("Married");


		c5.addItem("Male");
		c5.addItem("Female");

		
		for(int i=1; i<32; i++)
		{
			c91.addItem(i);
		}

		for(int i=1980; i<2018; i++)
		{
			c93.addItem(i);
		}
                
		
		t1=new TextField();
		t2=new TextField();
		t3=new TextField();
		t6=new TextField();
		t7=new TextField();
		t4=new TextField();
                t10=new TextField();

		f1.add(p1);
		p1.add(l1); p1.add(l2); p1.add(l3);
		p1.add(l4); p1.add(l5); p1.add(l6);
		p1.add(l7); p1.add(l8); p1.add(l9);
		p1.add(l10);
		
		p1.add(b3); p1.add(b1); p1.add(b2);
		p1.add(c91); p1.add(c92); p1.add(c93);
		p1.add(c5); p1.add(c8);

		p1.add(t4); p1.add(t1); p1.add(t2);p1.add(t3);
		p1.add(t6); p1.add(t7); p1.add(t10);


		l1.setBounds(50, 25,150,25);
		l2.setBounds(50, 75,150,25);
		l3.setBounds(50,125,150,25);
		l4.setBounds(50,175,150,25);
		l5.setBounds(50,225,150,25);
		l6.setBounds(50,275,150,25);
		l7.setBounds(50,325,150,25);
		l8.setBounds(50,375,150,25);
		l9.setBounds(50,425,150,25);
		l10.setBounds(50,475,150,25);

		t1.setBounds(250,25,150,25);
		t2.setBounds(250,75,150,25);
		t3.setBounds(250,125,150,25);
		t4.setBounds(250,175,150,25);
                t6.setBounds(250,275,150,25);
		t7.setBounds(250,325,150,25);
                t10.setBounds(250,475,150,25);

		b3.setBounds(275,525,100,25);
		b1.setBounds(75,525,100,25);
		b2.setBounds(175,525,100,25);
		
		c91.setBounds(250, 425,50,25);
		c92.setBounds(300, 425,50,25);
		c93.setBounds(350, 425,50,25);
		c5.setBounds(250, 225,150,25);
		c8.setBounds(250, 375,150,25);
	
	
		p1.setLayout(null);
		f1.setSize(450,625);
		f1.setVisible(true);
		f1.setLocationRelativeTo(null);
		p1.setLayout(null);
		f1.setResizable(false);

		b1.addActionListener(this);	
		b2.addActionListener(this);
		b3.addActionListener(this);
		

	}
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==b1) 
		{
			JOptionPane.showMessageDialog(f1, "button working");
                        String str1=t1.getText();
                        String str2=t2.getText();
                        String str3=t3.getText();
                        String str4=t4.getText();
                        
                        
                        String sc91=c91.getSelectedItem().toString();
                        String sc92=c92.getSelectedItem().toString();
                        String sc93=c93.getSelectedItem().toString();
                        
                        String dt=sc91+""+sc92+""+sc93;
                        
                        String sc5=c5.getSelectedItem().toString();
                          
                        String str6=t6.getText();
                        String str7=t7.getText();
                        String sc8=c8.getSelectedItem().toString();
                        String str10=t10.getText();                    
             /*
                        System.out.println(str1);
                        System.out.println(str2);
                        System.out.println(str3);
                        System.out.println(dt);
                        System.out.println(sc5);
                        System.out.println(str6);
                        System.out.println(str7);
                        System.out.println(str8);
                        System.out.println(str9);
                        System.out.println(sc10);
               */         
         	try
                {
                    String insertquery="insert into teacherreg values(?,?,?,?,?,?,?,?,?,?)";
                    
                    PreparedStatement pst=con.prepareStatement(insertquery);
                    
                    pst.setInt(1,Integer.parseInt(str1));
                    pst.setString(2,str2);
                    pst.setString(3,str3);
                    pst.setString(4,str4);
                    pst.setString(5,sc5);
                    pst.setString(6,str6);
                    pst.setString(7,str7);
                    pst.setString(8,sc8);
                    pst.setString(9,dt);
                    pst.setInt(10,Integer.parseInt(str10));
                    
                    pst.executeUpdate();
                    System.out.println("Data inserted");
               
                    JOptionPane.showMessageDialog(f1,"Data inserted");
                }
                catch(Exception e)
                {    
                 System.out.println("Data not inserted"+e);
                  JOptionPane.showMessageDialog(f1,"Data not inserted");  
                }
             }   
		if(ae.getSource()==b2)
		{
                    JOptionPane.showMessageDialog(f1, "button working");
                    
                        t1.setText(" ");
                        t2.setText(" ");
			t3.setText(" ");
                        t6.setText(" ");
			t7.setText(" ");
                        t4.setText("");
			t10.setText("");
                      
                }
                    
		if(ae.getSource()==b3)
		{
                    
                    JOptionPane.showMessageDialog(f1, "button working");	
                    home obj  =new home();
                }
                
            }
	
	public static void main(String a[])
	{
		new teacherreg();
	}
}